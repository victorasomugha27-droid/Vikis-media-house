VIKI'S MEDIA HOUSE — PROFESSIONAL WEBSITE PACKAGE

This is a redesigned, responsive multi-page website for Viki's Media House.
Brand direction: deep green, orange and warm off-white.
Slogan: Trusted News. Global Perspective.
Mission: Inform. Educate. Entertain.

PAGES
- index.html: homepage and newsroom sections
- about.html: about the organisation and mission
- contact.html: contact/news tip form
- editorial-policy.html: editorial standards
- styles.css and script.js: responsive styling and navigation
- assets/: logo and favicon

IMPORTANT
The homepage is a launch edition. It does not contain fabricated news reports.
The contact form is prepared for Netlify Forms. After deploying, open the site
in Netlify and confirm Forms are enabled/detected. Form handling depends on
Netlify's current site settings and plan.

HOW TO PUBLISH ON NETLIFY (iPhone)
1. Download this ZIP to the Files app.
2. Tap the ZIP once to extract it.
3. Open https://app.netlify.com/drop and sign in.
4. Upload the extracted website folder (or select all files inside it).
5. Wait for Netlify to finish deploying and give you a .netlify.app address.
6. Open the generated address to check the site.

If Netlify's picker does not accept a folder, open the extracted folder in Files,
select its contents, compress them into a ZIP, and upload that ZIP only if the
Netlify Drop page explicitly accepts ZIP uploads. Otherwise use a computer or
Netlify's manual deploy interface.

CUSTOMISATION
Replace contact details/social links once official newsroom contact information
and social accounts are confirmed. Add a CMS in a later phase to publish stories
without editing HTML. Do not add unverified claims, fake traffic numbers or
invented newsroom addresses.

NEWS UPDATES INCLUDED
The homepage now displays six category-based news summaries dated 24 November 2026.
Each card links to its source publisher or source archive. These are sourced summaries,
not original reporting. Re-check developing stories and attribution before posting.

FREE UPDATE WORKFLOW (NO SUBSCRIPTION)
The stories are stored in news/news.json. To change the public news cards, edit that
file and redeploy the site. A spreadsheet-friendly starter file is also included at
news/news-updater-template.csv. You can edit the CSV in Google Sheets, but the website
does not automatically sync to Google Sheets in this version.

For a true phone-friendly free updater, the recommended next step is to connect this
site to a GitHub repository and add a Git-based CMS. That requires the owner's GitHub
account and a one-time setup; Netlify Drop by itself does not provide a secure,
persistent editorial dashboard. Do not share passwords or access tokens in chat.
